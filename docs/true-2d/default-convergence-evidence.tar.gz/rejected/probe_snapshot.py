import numpy as np, time, subprocess, json, resource
from meent.on_numpy.emsolver.convolution_matrix import to_conv_mat_vector
from meent.on_numpy.emsolver.transfer_method import transfer_2d_2, transfer_2d_3, transfer_2d_4

def cell(px,py,L):
 d,wx,wy,n,k,b,bk=L;ni=complex(n,-k);bg=complex(b,-bk)
 if wx==0 or wy==0:return [np.array([[bg]]),np.array([[px]]),np.array([[py]])]
 xs=[px] if wx==px else [(px-wx)/2,(px+wx)/2,px]
 ys=[py] if wy==py else [(py-wy)/2,(py+wy)/2,py]
 vals=np.full((len(ys),len(xs)),bg,dtype=complex); vals[0 if len(ys)==1 else 1,0 if len(xs)==1 else 1]=ni
 return [vals,np.array(xs,dtype=complex)[:,None],np.array(ys,dtype=complex)[:,None]]

def solve(px=460,py=420,wl=632.8,theta=20,phi=25,hx=3,hy=3,n0=1,ns=1.5,ks=0,layers=(),factorization="inverse"):
 st=time.perf_counter();theta,phi=np.deg2rad([theta,phi]);nn=complex(ns,ks)
 kx=n0*np.sin(theta)*np.cos(phi)+np.arange(-hx,hx+1)*wl/px
 ky=n0*np.sin(theta)*np.sin(phi)+np.arange(-hy,hy+1)*wl/py
 xx,yy=np.meshgrid(kx,ky);rho2=xx**2+yy**2
 kt=np.sqrt((n0*n0-rho2).astype(complex)).flatten().conj();kb=np.sqrt(nn*nn-rho2).flatten().conj()
 varphi=np.arctan2(yy,xx);varphi[rho2==0]=phi;varphi=varphi.flatten()
 N=len(kt);I=np.eye(N,dtype=complex);O=np.zeros((N,N),complex)
 F=np.block([[I,O],[O,1j*np.diag(kb)/nn.conjugate()**2]])
 G=np.block([[1j*np.diag(kb),O],[O,I]]);T=np.eye(2*N,dtype=complex)
 active=[L for L in layers if L[0]>0]
 if active:
  ex,ey,ezi=to_conv_mat_vector([cell(px,py,L) for L in active],hx,hy,use_pinv=False)
  if factorization == "laurent":
   ex = np.linalg.inv(ezi); ey = ex.copy()
  for i in reversed(range(len(active))):
   W,V,q=transfer_2d_2(kx,ky,ex[i],ey[i],ezi[i],use_pinv=False)
   _,F,G,T,_,_=transfer_2d_3(2*np.pi/wl,W,V,q,active[i][0],varphi,F,G,T,use_pinv=False)
 res,_=transfer_2d_4(2*hx+1,2*hy+1,F,G,T,kt,kb,np.pi/2,theta,n0,nn.conjugate(),use_pinv=False)
 return res,time.perf_counter()-st

def s4(**kw):
 spec={"px":460,"py":420,"wl":632.8,"theta":20,"phi":25,"hx":3,"hy":3,"n0":1,"ns":1.5,"ks":0,"layers":[]};spec.update(kw)
 txt=' '.join(str(spec[k]) for k in ['px','py','wl','theta','phi','hx','hy','n0','ns','ks'])+' '+str(len(spec['layers']))+'\n'
 txt+='\n'.join(' '.join(map(str,L)) for L in spec['layers'])+'\n'
 out=subprocess.check_output([__import__('os').environ.get('S4_EXE','/tmp/rcwa-true2d-spike/s4_2d')],input=txt,text=True).splitlines();N=(2*spec['hx']+1)*(2*spec['hy']+1)
 ans={}
 for j,pol in enumerate(['s','p']):
  base=j*(N+1);tot=out[base].split();orders=[list(map(float,line.split())) for line in out[base+1:base+N+1]]
  ans[pol]={"R":float(tot[1]),"T":float(tot[2]),"orders":{(int(x),int(y)):[r,t] for x,y,r,t in orders}}
 return ans

def compare(**kw):
 r,t=solve(**kw); ref=s4(**kw);errs=[];ans={"seconds":t}
 for pol,key in [('s','res_te_inc'),('p','res_tm_inc')]:
  a=r[key];tot=[float(a['de_ri'].sum()),float(a['de_ti'].sum())];e=[abs(tot[0]-ref[pol]['R']),abs(tot[1]-ref[pol]['T'])]
  for (x,y),(rr,tt) in ref[pol]['orders'].items():
   e.extend([abs(a['de_ri'][y+kw.get('hy',3),x+kw.get('hx',3)]-rr),abs(a['de_ti'][y+kw.get('hy',3),x+kw.get('hx',3)]-tt)])
  ans[pol]={"orders": [{"m":x,"n":y,"R":float(a['de_ri'][y+kw.get('hy',3),x+kw.get('hx',3)]),"T":float(a['de_ti'][y+kw.get('hy',3),x+kw.get('hx',3)]),"S4_R":rr,"S4_T":tt} for (x,y),(rr,tt) in sorted(ref[pol]['orders'].items())], "RT":tot,"S4_RT":[ref[pol]['R'],ref[pol]['T']],"max_error":float(max(e)),"balance":1-sum(tot),"R_cross":float(a['de_ri_p' if pol=='s' else 'de_ri_s'].sum()),"T_cross":float(a['de_ti_p' if pol=='s' else 'de_ti_s'].sum())}
 return ans

if __name__=='__main__':
 cases={
 'bare_normal':dict(layers=[],theta=0,phi=0),
 'planar_normal':dict(layers=[[90,460,420,2.1,0,1,0],[120,460,420,1.8,0.08,1,0]],theta=0,phi=0),
 'planar_lossy_port':dict(layers=[[90,460,420,2.1,0,1,0],[120,460,420,1.8,0.08,1,0]],theta=37,phi=23,ns=0.4,ks=3.1),
 'pillar_normal':dict(layers=[[110,220,180,2.2,0,1,0]],theta=0,phi=0),
 'pillar_oblique':dict(layers=[[110,220,180,2.2,0,1,0]],theta=20,phi=25),
 'stack_2d':dict(layers=[[110,220,180,2.2,0,1,0],[80,460,420,1.45,0,1,0],[130,290,240,1.9,0,1,0]],theta=20,phi=25),
 'stack_2d_lossy_port':dict(layers=[[110,220,180,2.2,0,1,0],[80,460,420,1.45,0,1,0],[130,290,240,1.9,0.02,1,0]],theta=20,phi=25,ns=0.4,ks=3.1),
 }
 evidence={}
 for name,kw in cases.items():
  try:evidence[name]={'input':kw,'result':compare(**kw)}
  except Exception as exc:evidence[name]={'error':str(exc)}
  print(name,json.dumps(evidence[name]),flush=True)
 open('/tmp/rcwa-true2d-spike/evidence.json','w').write(json.dumps(evidence,indent=2))
