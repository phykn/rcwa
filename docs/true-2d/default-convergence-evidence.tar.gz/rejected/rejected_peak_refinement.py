from validate import *
wls=[656.5,657,657.5,756.5,757,757.5,805,805.25,805.5,805.75,806,806.25,806.5,806.75,807]
for h in [3,5,7]:
 for wl in wls:run('meent',h,wl)
rows=[{'wavelength_nm':wl,**short_compare(run('meent',5,wl),run('meent',7,wl)),'totals':{str(h):{p:run('meent',h,wl)['polarizations'][p]['totals'] for p,_ in POLS} for h in [3,5,7]}} for wl in wls]
peaks={}
for band,lo,hi in [('657nm',656.5,657.5),('757nm',756.5,757.5),('806nm',805,807)]:
 peaks[band]={}
 for h in [3,5,7]:
  peaks[band][str(h)]={}
  for p,_ in POLS:
   local=[(wl,run('meent',h,wl)['polarizations'][p]['totals']['R']) for wl in wls if lo<=wl<=hi]
   peaks[band][str(h)][p]={'R_max':max(local,key=lambda x:x[1]),'R_min':min(local,key=lambda x:x[1])}
dump('rejected-peak-refinement.json',{'wavelengths_nm':wls,'rows':rows,'peaks':peaks,'worst':max(rows,key=lambda r:r['maximum']['absolute'])})
print(json.dumps({'worst':max(rows,key=lambda r:r['maximum']['absolute']),'peaks':peaks},indent=2))
