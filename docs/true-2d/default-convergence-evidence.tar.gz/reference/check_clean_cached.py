import validate as v
from validate import *
v.S4=str(OUT/'s4_2d_cross_cached');rows=[]
for h,wl in [(5,450),(5,630),(5,850),(7,450)]:
 a=run('S4',h,wl);b=run('S4_clean_cached_check',h,wl);rows.append({'H':h,'wavelength_nm':wl,'comparison':short_compare(a,b),'seconds_reference':a['seconds'],'seconds_cached':b['seconds']})
dump('clean-driver-equivalence.json',rows);print(json.dumps(rows,indent=2))
