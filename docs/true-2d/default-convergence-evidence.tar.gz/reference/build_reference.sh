#!/usr/bin/env bash
set -euo pipefail
out=/tmp/rcwa-2d-default-validation
src=/tmp/rcwa-s4-upstream
blas=/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages/casadi/libcasadi-tp-openblas.so
[ "$(git -C "$src" rev-parse HEAD)" = 7fd00a231610bff51f5c7de5f723e3956eab7453 ]
git -C "$src" diff --exit-code HEAD -- >/dev/null
# All official source files are compiled unchanged into a separate absolute build directory.
# HAVE_BLAS/HAVE_LAPACK are upstream-supported build options; no S4 algorithm or matrices are replaced.
make -C "$src" -j1 OBJDIR="$out/s4-clean-build" LAPACK_LIB=1 \
 CPPFLAGS='-IS4 -IS4/RNP -IS4/kiss_fft -DHAVE_BLAS -DHAVE_LAPACK' \
 CFLAGS='-O3 -Wall -march=native -fcx-limited-range -fno-exceptions -fPIC' \
 CXXFLAGS='-O3 -Wall -march=native -fcx-limited-range -fno-exceptions -fPIC' \
 "$out/s4-clean-build/libS4.a"
cp "$out/s4-clean-build/libS4.a" "$out/libS4_lapack.a"
g++ -O2 -std=c++11 -I"$src/S4" "$out/s4_2d_cross_cached.cpp" "$out/libS4_lapack.a" "$blas" -Wl,-rpath,"$(dirname "$blas")" -o "$out/s4_2d_cross_cached"
git -C "$src" diff --exit-code HEAD -- >/dev/null
g++ --version | head -1
sha256sum "$out/libS4_lapack.a" "$out/s4_2d_cross_cached.cpp" "$out/s4_2d_cross_cached" "$src/S4/rcwa.cpp" "$blas"
