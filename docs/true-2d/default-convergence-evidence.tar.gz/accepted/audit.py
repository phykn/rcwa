from validate import *
def add_max(dst,key,value,location):
 if key not in dst or abs(value)>dst[key]['absolute']:dst[key]={'absolute':abs(value),'signed':value,**location}
if __name__=='__main__':
 audit={'accepted_cache_entries_verified':0,'exploratory_H3_entries':0,'sample_count':0,'minimum_order_power':1,'timings':{},'maximums':{}}
 for path in (OUT/'samples').rglob('*.json'):
  x=json.loads(path.read_text());audit['sample_count']+=1;tag=path.relative_to(OUT/'samples').parts[0];engine=x['engine'];h=x['H'];wl=x['wavelength_nm'];group=f'{tag}/{engine}/H{h}';audit['timings'][group]=audit['timings'].get(group,0)+x['seconds']
  if h>=5:
   expected_spec=SPEC if tag=='default' else json.loads((OUT/'pattern-effects-summary.json').read_text())[tag]['input']
   expected_cfg=normalized_cfg(expected_spec,h,wl)
   assert x['input']==expected_cfg
   identity=cache_identity(engine,expected_cfg)
   assert all(x.get(k)==v for k,v in identity.items())
   if engine=='meent':
    assert x['implementation']=='actual forward_2d'
    meta=x['production_metadata'];assert meta['factorization']=='directional_inverse_rule'
    assert meta['harmonics_x']==h and meta['harmonics_y']==h and meta['basis_size']==(2*h+1)**2
    assert meta['offline_reference_override']==(h>5)
   audit['accepted_cache_entries_verified']+=1
  else:
   if x.get('implementation')=='actual forward_2d':
    expected_cfg=normalized_cfg(SPEC,h,wl);assert x['input']==expected_cfg
    assert all(x.get(k)==v for k,v in cache_identity(engine,expected_cfg).items())
   else:assert x.get('implementation')=='probe discovery only'
   audit['exploratory_H3_entries']+=1
  expected={(m,n) for n in range(-h,h+1) for m in range(-h,h+1)}
  for p,_ in POLS:
   dat=x['polarizations'][p];location={'engine':engine,'H':h,'wavelength_nm':wl,'polarization':p,'tag':tag}
   assert {(r['m'],r['n']) for r in dat['orders']}==expected
   assert len(dat['orders'])==len(expected)
   add_max(audit['maximums'],'lossless_balance',1-dat['totals']['R']-dat['totals']['T'],location)
   for f in FIELDS:
    add_max(audit['maximums'],'order_total_identity',sum(o[f] for o in dat['orders'])-dat['totals'][f],{**location,'field':f})
   for r in dat['orders']:
    for f in FIELDS:
     assert math.isfinite(r[f]);audit['minimum_order_power']=min(audit['minimum_order_power'],r[f])
    for side in ['R','T']:
     add_max(audit['maximums'],'order_component_identity',r[side]-r[side+'_s']-r[side+'_p'],{**location,'m':r['m'],'n':r['n'],'field':side})
   for side in ['R','T']:
    add_max(audit['maximums'],'total_component_identity',dat['totals'][side]-dat['totals'][side+'_s']-dat['totals'][side+'_p'],{**location,'field':side})
 dump('integrity-audit.json',audit)
 # Dense and base sample arrays packaged losslessly in independently readable NumPy NPZ.
 arrays={};manifest=[]
 for path in sorted((OUT/'samples').rglob('*.json')):
  x=json.loads(path.read_text());tag=path.relative_to(OUT/'samples').parts[0];key=f"{tag}_{x['engine']}_H{x['H']}_wl{x['wavelength_nm']:.9f}".replace('.','p')
  arrays[key+'_orders']=np.array([[o['m'],o['n']] for o in x['polarizations']['s']['orders']],dtype=np.int32)
  arrays[key+'_power']=np.array([[[o[f] for f in FIELDS] for o in x['polarizations'][p]['orders']] for p,_ in POLS],dtype=np.float64)
  arrays[key+'_totals']=np.array([[x['polarizations'][p]['totals'][f] for f in FIELDS] for p,_ in POLS],dtype=np.float64)
  manifest.append({'key':key,'input':x['input'],'engine':x['engine'],'seconds':x['seconds'],'tag':tag,'implementation':x.get('implementation'),'generation_id':x.get('generation_id'),'input_sha256':x.get('input_sha256'),'cache_fingerprint':x.get('cache_fingerprint')})
 np.savez_compressed(OUT/'all-component-arrays.npz',**arrays)
 dump('array-manifest.json',{'format':'NPZ: {key}_orders [order, (m,n)], {key}_power [incident s/p, order, field], {key}_totals [incident s/p, field]','fields':FIELDS,'polarizations':['s','p'],'samples':manifest})
 print(json.dumps(audit,indent=2))
 # Exact proposed default input, including names, its full 21-wavelength vector, and normal shipped H5 call.
 from rcwa_core.solver_2d import input_hash_2d
 project=Project2D.model_validate(json.loads((OUT/'candidate-project.json').read_text()))
 before=cache_identity('meent',normalized_cfg(SPEC,5,450));started=time.perf_counter();batch=forward_2d(project);elapsed=time.perf_counter()-started
 assert cache_identity('meent',normalized_cfg(SPEC,5,450))==before
 from rcwa_core.contracts_2d import validate_result_2d
 validate_result_2d(batch,project)
 from rcwa_core.contracts_2d import PublicForwardResult2D
 from rcwa_core.project_io import normalized_project_and_hash,validate_result_for_project
 PublicForwardResult2D.model_validate(batch,strict=True)
 validate_result_for_project('forward',batch,project)
 assert normalized_project_and_hash(project)[2]==batch['metadata']['input_hash']==input_hash_2d(project)=='eeb26da3484602221944f1784b4b93ce2ed76f89b61e95d34bb68730be7bddc7'
 dump('candidate-result-H5.json',batch)
 worst={'absolute':-1}
 for i,wl in enumerate(project.illumination.wavelengths_nm):
  cached=run('meent',5,wl)
  for p,_ in POLS:
   aa={(r['m'],r['n']):r for r in cached['polarizations'][p]['orders']}
   for row in batch['spectra'][p]['orders'][i]:
    for f in FIELDS:
     d=row[f]-aa[row['m'],row['n']][f]
     if abs(d)>worst['absolute']:worst={'absolute':abs(d),'signed':d,'wavelength_nm':wl,'polarization':p,'m':row['m'],'n':row['n'],'field':f}
 exact={'PublicForwardResult2D_passed':True,'shared_validate_result_for_project_passed':True,'exact_shared_hash_matched':True,'metadata_stage':batch['metadata']['stage'],'adapter_version':batch['metadata']['adapter_version'],'validate_result_2d_passed':True,'generation_id':get_generation('meent')[0],'input_hash':input_hash_2d(project),'seconds':elapsed,'offline_reference_override':batch['metadata']['offline_reference_override'],'maximum_vs_single_wavelength_actual_samples':worst}
 dump('candidate-exact-replay.json',exact);print('EXACT_REPLAY',json.dumps(exact))
 dump('provenance-final.json',provenance())
 subprocess.check_call([sys.executable,str(OUT/'bind_comparisons.py')])
 subprocess.check_call([sys.executable,str(OUT/'acceptance.py')])
 subprocess.check_call([sys.executable,str(OUT/'package_evidence.py')])
