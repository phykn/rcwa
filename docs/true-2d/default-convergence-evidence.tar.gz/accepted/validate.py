import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'): os.environ[k]='1'
import sys, time, json, subprocess, hashlib, platform, importlib.metadata, resource, math
from pathlib import Path
import numpy as np
sys.path.insert(0,'/workspace/shared/rcwa-2d-integration-stage/backend')
from rcwa_core.schemas_2d import Project2D
from rcwa_core.solver_2d import forward_2d

def production_solve(cfg):
 layers=[]
 for i,(d,wx,wy,n,k,b,bk) in enumerate(cfg['layers']):
  common={'name':f'Synthetic layer {i+1}','thickness_nm':d,'material':{'name':f'Synthetic inclusion {i+1}','n':n,'k':k}}
  if wx==cfg['px'] and wy==cfg['py']:layers.append(dict(common,geometry='homogeneous'))
  else:layers.append(dict(common,geometry='rectangle_2d',cd_x_nm=wx,cd_y_nm=wy,background={'name':f'Synthetic background {i+1}','n':b,'k':bk}))
 proj=Project2D.model_validate({'schema_version':'1.2','name':'Synthetic subwavelength 2D dielectric stack','period_nm':cfg['px'],'period_y_nm':cfg['py'],'ambient':{'name':'Synthetic ambient','n':cfg['n0'],'k':0},'substrate':{'name':'Synthetic substrate','n':cfg['ns'],'k':cfg['ks']},'layers':layers,'illumination':{'wavelengths_nm':[cfg['wl']],'angle_deg':cfg['theta'],'azimuth_deg':cfg['phi'],'polarization':'both'},'solver':{'harmonics_x':min(cfg['hx'],5),'harmonics_y':min(cfg['hy'],5)}})
 override=(cfg['hx'],cfg['hy']) if max(cfg['hx'],cfg['hy'])>5 else None
 return forward_2d(proj,reference_basis=override)

OUT=Path(__file__).resolve().parent
S4='/tmp/rcwa-2d-default-validation/s4_2d_cross_cached'
SPEC=dict(px=150,py=140,theta=20,phi=25,n0=1,ns=1.5,ks=0,layers=[[90,70,60,1.65,0,1.45,0],[180,150,140,2.1,0,1,0],[130,95,80,1.45,0,1.6,0]])
FIELDS=['R','T','R_s','R_p','T_s','T_p']
KEYS=['de_ri','de_ti','de_ri_s','de_ri_p','de_ti_s','de_ti_p']
POLS=[('s','res_te_inc'),('p','res_tm_inc')]

def dump(name,x):
 p=OUT/name;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,indent=2,allow_nan=False));t.replace(p)

GENERATION_CACHE={}
CORE_CHECKPOINT='d2c00e55a699e75b58cc20de69d0f148718dc0c2'
def normalized_cfg(spec,h,wl):
 cfg={k:float(spec[k]) for k in ['px','py','theta','phi','n0','ns','ks']}
 cfg.update(wl=float(wl),hx=int(h),hy=int(h),layers=[[float(v) for v in layer] for layer in spec['layers']])
 return cfg

def get_generation(engine):
 if engine in GENERATION_CACHE:return GENERATION_CACHE[engine]
 import meent.on_numpy.emsolver.transfer_method as tm
 import meent.on_numpy.emsolver.convolution_matrix as cm
 import meent.on_numpy.emsolver.fourier_analysis as fa
 import meent.on_numpy.emsolver._base as base
 files=[Path(__file__)]
 if engine=='meent':
  files += sorted(Path('/workspace/shared/rcwa-2d-integration-stage/backend/rcwa_core').glob('*.py'))
  files += [Path(m.__file__) for m in [tm,cm,fa,base]]
  dirty=subprocess.check_output(['git','-C','/workspace/shared/rcwa-2d-integration-stage','diff','--name-only',CORE_CHECKPOINT,'--','backend/rcwa_core'],text=True)
  if dirty:raise ValueError('Production core differs from frozen checkpoint: '+dirty)
  implementation='rcwa_core.solver_2d.forward_2d'
 else:
  files += [Path(S4),Path('/tmp/rcwa-2d-default-validation/s4_2d_cross_cached.cpp'),Path('/tmp/rcwa-2d-default-validation/build_reference.sh'),Path('/tmp/rcwa-2d-default-validation/libS4_lapack.a'),Path('/tmp/rcwa-s4-upstream/S4/rcwa.cpp'),Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages/casadi/libcasadi-tp-openblas.so')]
  dirty=subprocess.check_output(['git','-C','/tmp/rcwa-s4-upstream','diff','--name-only','HEAD'],text=True)
  pinned=subprocess.check_output(['git','-C','/tmp/rcwa-s4-upstream','rev-parse','HEAD'],text=True).strip()
  if dirty or pinned!='7fd00a231610bff51f5c7de5f723e3956eab7453':raise ValueError('Reference source pin or tracked-clean condition failed')
  implementation='Independent S4 public-excitation cached driver; default Laurent formulation; HAVE_BLAS/HAVE_LAPACK; single-thread OpenBLAS'
 manifest={'format_version':1,'engine':engine,'implementation':implementation,'core_checkpoint':CORE_CHECKPOINT,'S4_commit':'7fd00a231610bff51f5c7de5f723e3956eab7453','python':sys.version,'meent':importlib.metadata.version('meent'),'numpy':np.__version__,'environment':{k:os.environ[k] for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS')},'hashes':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}}
 content=json.dumps(manifest,sort_keys=True,separators=(',',':'));gid=hashlib.sha256(content.encode()).hexdigest()
 folder=OUT/'generations';folder.mkdir(exist_ok=True);path=folder/(gid+'.json')
 if path.exists() and path.read_text()!=content:raise ValueError('Immutable generation manifest conflict')
 if not path.exists():path.write_text(content)
 GENERATION_CACHE[engine]=(gid,manifest)
 return gid,manifest

def cache_identity(engine,cfg):
 dirty=subprocess.check_output(['git','-C','/workspace/shared/rcwa-2d-integration-stage','diff','--name-only',CORE_CHECKPOINT,'--','backend/rcwa_core'],text=True)
 if dirty:raise ValueError('Production core changed during evidence generation: '+dirty)
 gid,manifest=get_generation(engine)
 for path,expected in manifest['hashes'].items():
  if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=expected:raise ValueError('Generation source/binary changed while running: '+path)
 canonical=json.dumps(cfg,sort_keys=True,separators=(',',':'))
 ih=hashlib.sha256(canonical.encode()).hexdigest()
 return {'generation_id':gid,'input_sha256':ih,'cache_fingerprint':hashlib.sha256((gid+':'+ih).encode()).hexdigest()}

def run(engine,h,wl,spec=SPEC,tag='default'):
 cfg=normalized_cfg(spec,h,wl);identity=cache_identity(engine,cfg)
 cache=OUT/'samples'/tag/engine/f'H{h}'/f'{wl:.9f}.json'
 if cache.exists():
  existing=json.loads(cache.read_text())
  if any(existing.get(k)!=v for k,v in identity.items()) or existing['input']!=cfg:raise ValueError('Cache fingerprint/input mismatch: '+str(cache))
  if engine=='meent' and (existing.get('implementation')!='actual forward_2d' or existing.get('production_metadata',{}).get('factorization')!='directional_inverse_rule'):raise ValueError('Ambiguous production cache: '+str(cache))
  if cache_identity(engine,cfg)!=identity:raise ValueError('Generation changed during cache read')
  return existing
 cache.parent.mkdir(parents=True,exist_ok=True)
 t=time.perf_counter()
 if engine=='meent':
  result=production_solve(cfg);pols={}
  for p,key in POLS:
   series=result['spectra'][p];order=[{'m':r['m'],'n':r['n'],**{f:r[f] for f in FIELDS}} for r in series['orders'][0]]
   totals={f:sum(r[f] for r in order) for f in FIELDS};totals['R']=series['R'][0];totals['T']=series['T'][0]
   pols[p]={'totals':totals,'orders':order}

 else:
  txt=' '.join(str(cfg[k]) for k in ['px','py','wl','theta','phi','hx','hy','n0','ns','ks'])+' '+str(len(cfg['layers']))+'\n'+'\n'.join(' '.join(map(str,L)) for L in cfg['layers'])+'\n'
  lines=subprocess.check_output([S4],input=txt,text=True).splitlines();N=(2*h+1)**2;pols={}
  if len(lines)!=2*(N+1):raise ValueError('S4 unexpected output lines')
  for j,(p,_) in enumerate(POLS):
   head=lines[j*(N+1)].split()
   if head[0]!=p or int(head[4])!=N:raise ValueError('S4 input/basis header mismatch')
   rows=[]
   for line in lines[j*(N+1)+1:(j+1)*(N+1)]:
    vals=line.split();m,n=map(int,vals[:2]);rows.append({'m':m,'n':n,**dict(zip(FIELDS,map(float,vals[2:])) )})
   if {(r['m'],r['n']) for r in rows}!={(m,n) for n in range(-h,h+1) for m in range(-h,h+1)} or len(rows)!=N:raise ValueError('S4 explicit returned G mismatch')
   rows.sort(key=lambda r:(r['n'],r['m']))
   totals={f:sum(r[f] for r in rows) for f in FIELDS};totals['R']=float(head[1]);totals['T']=float(head[2])
   pols[p]={'totals':totals,'incident_flux':float(head[3]),'orders':rows}
 sample={**identity,'acceptance_role':'exploratory_discovery_only' if h<5 else 'accepted_basis_candidate','implementation':'actual forward_2d' if engine=='meent' else 'independent S4 cached public-excitation driver','engine':engine,'H':h,'wavelength_nm':wl,'input':cfg,'polarizations':pols,'seconds':time.perf_counter()-t}
 if engine=='meent':sample['production_metadata']=result['metadata']
 for p in pols.values():
  if not all(math.isfinite(v) for row in p['orders'] for v in [row[f] for f in FIELDS]):raise ValueError('nonfinite')
  if abs(1-p['totals']['R']-p['totals']['T'])>1e-6:raise ValueError('lossless balance')
  if min(row[f] for row in p['orders'] for f in FIELDS)<-1e-8:raise ValueError('negative flux')
 if cache_identity(engine,cfg)!=identity:raise ValueError('Generation changed during solve')
 cache.write_text(json.dumps(sample,allow_nan=False,separators=(',',':')))
 print(engine,h,wl,round(sample['seconds'],3),flush=True)
 return sample

def compare(a,b):
 # b minus a, common orders are mapped by integer (m,n), not array position.
 signed=[];tails=[];maxerr={'absolute':-1};tailmax={'absolute':-1}
 for p,_ in POLS:
  pa,pb=a['polarizations'][p],b['polarizations'][p]
  for f in FIELDS:
   d=pb['totals'][f]-pa['totals'][f];row={'polarization':p,'kind':'total','field':f,'signed_delta':d};signed.append(row)
   if abs(d)>maxerr['absolute']:maxerr={**row,'absolute':abs(d)}
  aa={(r['m'],r['n']):r for r in pa['orders']};bb={(r['m'],r['n']):r for r in pb['orders']}
  for order in sorted(aa.keys()&bb.keys(),key=lambda x:(x[1],x[0])):
   for f in FIELDS:
    d=bb[order][f]-aa[order][f];row={'polarization':p,'kind':'order','m':order[0],'n':order[1],'field':f,'signed_delta':d};signed.append(row)
    if abs(d)>maxerr['absolute']:maxerr={**row,'absolute':abs(d)}
  for f in FIELDS:
   d=sum(bb[o][f] for o in bb.keys()-aa.keys());row={'polarization':p,'field':f,'sum':d,'orders':[[m,n] for m,n in sorted(bb.keys()-aa.keys(),key=lambda x:(x[1],x[0]))]};tails.append(row)
   if abs(d)>tailmax['absolute']:tailmax={**row,'absolute':abs(d)}
 return {'maximum':maxerr,'added_order_tail_maximum':tailmax,'added_order_tails':tails,'signed_residuals':signed}

def short_compare(a,b):
 c=compare(a,b);return {k:c[k] for k in ['maximum','added_order_tail_maximum']}

def cutoff_roots():
 a=math.sin(math.radians(SPEC['theta']))*math.cos(math.radians(SPEC['phi']));b=math.sin(math.radians(SPEC['theta']))*math.sin(math.radians(SPEC['phi']));out=[]
 for port,nport in [('ambient',SPEC['n0']),('substrate',SPEC['ns'])]:
  for m in range(-3,4):
   for n in range(-3,4):
    A=(m/SPEC['px'])**2+(n/SPEC['py'])**2;B=2*(a*m/SPEC['px']+b*n/SPEC['py']);C=a*a+b*b-nport*nport
    if A==0:continue
    discr=B*B-4*A*C
    if discr<0:continue
    for r in [(-B-math.sqrt(discr))/(2*A),(-B+math.sqrt(discr))/(2*A)]:
     if 450<r<850:out.append({'port':port,'m':m,'n':n,'wavelength_nm':r})
 return sorted(out,key=lambda r:r['wavelength_nm'])

def provenance():
 import meent.on_numpy.emsolver.transfer_method as tm
 import meent.on_numpy.emsolver.convolution_matrix as cm
 import meent.on_numpy.emsolver.fourier_analysis as fa
 import meent.on_numpy.emsolver._base as base
 files=[Path('/tmp/rcwa-2d-default-validation/s4_2d_cross_cached.cpp'),Path('/tmp/rcwa-2d-default-validation/build_reference.sh'),Path('/tmp/rcwa-2d-default-validation/libS4_lapack.a'),Path('/tmp/rcwa-s4-upstream/S4/rcwa.cpp'),Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages/casadi/libcasadi-tp-openblas.so'),Path(__file__),Path(S4)]+[Path(m.__file__) for m in [tm,cm,fa,base]]
 files.extend(sorted(Path('/workspace/shared/rcwa-2d-integration-stage/backend/rcwa_core').glob('*.py')))
 tracked=subprocess.check_output(['git','-C','/tmp/rcwa-s4-upstream','diff','--name-only','HEAD'],text=True)
 sha=subprocess.check_output(['git','-C','/tmp/rcwa-s4-upstream','rev-parse','HEAD'],text=True).strip()
 if tracked or sha!='7fd00a231610bff51f5c7de5f723e3956eab7453':raise ValueError('S4 pinned tracked-clean provenance failure')
 return {'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'meent':importlib.metadata.version('meent'),'numpy':np.__version__,'S4_commit':sha,'S4_tracked_diff':tracked,'production_implementation':'Actual offline rcwa_core.solver_2d.forward_2d; H5 uses normal solver basis, H7/H9 explicitly record offline override; fresh actual-module H3 discovery is exploratory only and excluded from acceptance', 'S4_build':'Official rcwa.cpp compiled with HAVE_BLAS and HAVE_LAPACK; LP64 OpenBLAS; source unchanged; see build_reference.sh and original-driver equivalence evidence', 'S4_options':'unmodified official default 2D Laurent Fourier formulation; explicit rectangular G list; independent rectangle construction and Hx/Hy-amplitude outgoing s/p projection; all default options','environment':{k:os.environ[k] for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS')},'hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}

if __name__=='__main__':
 mode=sys.argv[1] if len(sys.argv)>1 else 'screen'
 if mode=='screen':
  out={'input':SPEC,'roots':cutoff_roots(),'rows':[]}
  for wl in list(range(450,851,40)):
   a=run('meent',3,wl);b=run('meent',5,wl)
   out['rows'].append({'wl':wl,'refinement':short_compare(a,b),'totals':{p:b['polarizations'][p]['totals'] for p,_ in POLS}})
  dump('screen.json',out);print(json.dumps({'cutoffs':out['roots'],'max_refinement':max(r['refinement']['maximum']['absolute'] for r in out['rows']),'R_range':{p:[min(r['totals'][p]['R'] for r in out['rows']),max(r['totals'][p]['R'] for r in out['rows'])] for p,_ in POLS}},indent=2))
 elif mode=='full':
  dump('provenance.json',provenance());wls=list(range(450,851,20));summary={'input':SPEC,'wavelengths_nm':wls,'thresholds':{'refinement':5e-4,'independent':2e-3},'comparisons':{}}
  for engine in ['meent','S4']:
   for h in [5,7,9]:
    for wl in wls:run(engine,h,wl)
  for label,eng_a,ha,eng_b,hb in [('meent_H5_H7','meent',5,'meent',7),('meent_H7_H9','meent',7,'meent',9),('S4_H5_H7','S4',5,'S4',7),('S4_H7_H9','S4',7,'S4',9),('meent_H5_H9','meent',5,'meent',9),('meent_H5_S4_H9','meent',5,'S4',9),('meent_H9_S4_H9','meent',9,'S4',9)]:
   details=[{'wavelength_nm':wl,**compare(run(eng_a,ha,wl),run(eng_b,hb,wl))} for wl in wls];dump(label+'.json',details)
   worst=max(details,key=lambda x:x['maximum']['absolute']);tail=max(details,key=lambda x:x['added_order_tail_maximum']['absolute'])
   summary['comparisons'][label]={'worst':{'wavelength_nm':worst['wavelength_nm'],**worst['maximum']},'worst_tail':{'wavelength_nm':tail['wavelength_nm'],**tail['added_order_tail_maximum']},'per_wavelength':[{'wavelength_nm':r['wavelength_nm'],'maximum':r['maximum'],'tail':r['added_order_tail_maximum']['absolute']} for r in details]}
  summary['timings']={engine:{str(h):sum(run(engine,h,wl)['seconds'] for wl in wls) for h in [5,7,9]} for engine in ['meent','S4']}
  summary['peak_parent_rss_KiB']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
  summary['peak_child_rss_KiB']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
  dump('full-summary.json',summary);print(json.dumps(summary,indent=2));dump('provenance-after.json',provenance())
