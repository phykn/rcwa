from validate import *
import copy, shutil
src=OUT/'samples/default/meent/H5/450.000000000.json';original=json.loads(src.read_text());directory=OUT/'samples/_cache_rejection_test/meent/H5';directory.mkdir(parents=True,exist_ok=True);path=directory/src.name;tests=[]
try:
 for label,mutator in [
  ('changed_geometry',lambda x:x['input']['layers'][0].__setitem__(2,61.0)),
  ('missing_generation',lambda x:x.pop('generation_id')),
  ('different_generation',lambda x:x.__setitem__('generation_id','wrong')),
  ('probe_cache',lambda x:x.__setitem__('implementation','probe discovery only')),
  ('different_factorization',lambda x:x['production_metadata'].__setitem__('factorization','diagnostic_laurent')),
 ]:
  data=copy.deepcopy(original);mutator(data);path.write_text(json.dumps(data))
  try:run('meent',5,450,tag='_cache_rejection_test')
  except ValueError as error:tests.append({'case':label,'rejected':True,'message':str(error)})
  else:raise AssertionError('Invalid cache was accepted: '+label)
 # A correct cache hit must return only the original generation and numerical arrays.
 path.write_text(json.dumps(original));returned=run('meent',5,450,tag='_cache_rejection_test');assert returned==original
 tests.append({'case':'unchanged_fingerprinted_cache','accepted':True})
finally:shutil.rmtree(OUT/'samples/_cache_rejection_test')
dump('cache-rejection-tests.json',tests);print(json.dumps(tests,indent=2))
