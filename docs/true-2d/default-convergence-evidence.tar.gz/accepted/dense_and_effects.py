from validate import *

def spectrum_rows(h=3,step=1):
 return [{'wavelength_nm':wl,'totals':{p:run('meent',h,wl)['polarizations'][p]['totals'] for p,_ in POLS}} for wl in np.arange(450,850+step/2,step).tolist()]

def candidates(scan):
 # Find actual sampled extrema, curvature and steepest change rather than assuming smoothness.
 found=[]
 for p,_ in POLS:
  for f in FIELDS:
   vals=np.array([r['totals'][p][f] for r in scan]);wls=np.array([r['wavelength_nm'] for r in scan])
   from scipy.signal import find_peaks
   for sign in [1,-1]:
    for i in find_peaks(sign*vals,prominence=1e-5)[0]:
     found.append({'kind':'sampled_extremum','polarization':p,'field':f,'wavelength_nm':float(wls[i]),'value':float(vals[i]),'minimum_prominence':1e-5})
   grad=np.abs(np.diff(vals));i=int(grad.argmax());found.append({'kind':'steepest_interval','polarization':p,'field':f,'wavelength_nm':float((wls[i]+wls[i+1])/2),'change':float(grad[i])})
 return found

if __name__=='__main__':
 mode=sys.argv[1] if len(sys.argv)>1 else 'scan'
 if mode=='scan':
  scan=spectrum_rows(h=3,step=1);found=candidates(scan);dump('dense-scan-H3.json',{'acceptance_role':'exploratory_discovery_only','implementation':'actual forward_2d','spacing_nm':1,'rows':scan,'feature_candidates':found,'cutoffs':cutoff_roots()})
  print(json.dumps(found,indent=2))
 elif mode=='dense':
  scan=json.loads((OUT/'dense-scan-H3.json').read_text());found=scan['feature_candidates']
  # H5 scan around all total/channel extrema and steepest intervals on 0.5nm grid, plus all cutoff neighborhoods.
  centers=sorted({f['wavelength_nm'] for f in found})
  wls=sorted({float(round(c+d,9)) for c in centers for d in [-1,-.5,0,.5,1] if 450<=c+d<=850}|{float(round(c['wavelength_nm']+d,9)) for c in cutoff_roots() for d in [-1,-.1,.1,1]})
  rows=[]
  for wl in wls:
   x=run('meent',5,wl);rows.append({'wavelength_nm':wl,'totals':{p:x['polarizations'][p]['totals'] for p,_ in POLS}})
  summary={'centers_nm':centers,'wavelengths_nm':wls,'rows':rows,'feature_candidates':found}
  dump('dense-H5.json',summary)
  print(json.dumps({'centers':centers,'sample_count':len(wls)},indent=2))
 elif mode=='refine':
  dense=json.loads((OUT/'dense-H5.json').read_text())
  # Every dense discovery sample is independently refined; no selection of only favorable points.
  wls=dense['wavelengths_nm']
  dump('dense-refinement-plan.json',{'wavelengths_nm':wls,'sample_count':len(wls),'selection':'All 40 points in +/-1nm windows around every H3 total/channel extremum or steepest interval, at 0.5nm spacing; no external cutoff exists in this subwavelength band','orchestration_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
  for engine in ['meent','S4']:
   for h in [5,7,9]:
    for wl in wls:run(engine,h,wl)
  summary={'wavelengths_nm':wls,'comparisons':{}}
  for label,ea,ha,eb,hb in [('meent_H5_H7','meent',5,'meent',7),('meent_H7_H9','meent',7,'meent',9),('S4_H5_H7','S4',5,'S4',7),('S4_H7_H9','S4',7,'S4',9),('meent_H5_H9','meent',5,'meent',9),('meent_H5_S4_H9','meent',5,'S4',9)]:
   details=[{'wavelength_nm':wl,**compare(run(ea,ha,wl),run(eb,hb,wl))} for wl in wls];dump('dense-'+label+'.json',details)
   worst=max(details,key=lambda r:r['maximum']['absolute']);tail=max(details,key=lambda r:r['added_order_tail_maximum']['absolute'])
   summary['comparisons'][label]={'worst':{'wavelength_nm':worst['wavelength_nm'],**worst['maximum']},'worst_tail':{'wavelength_nm':tail['wavelength_nm'],**tail['added_order_tail_maximum']}}
  peaks={}
  for c in dense['centers_nm']:
   local=[wl for wl in wls if abs(wl-c)<=1.0000001];peaks[str(c)]={}
   for engine in ['meent','S4']:
    peaks[str(c)][engine]={}
    for h in [5,7,9]:
     peaks[str(c)][engine][str(h)]={}
     for p,_ in POLS:
      vals=[(wl,run(engine,h,wl)['polarizations'][p]['totals']['R']) for wl in local]
      peaks[str(c)][engine][str(h)][p]={'maximum':max(vals,key=lambda t:t[1]),'minimum':min(vals,key=lambda t:t[1])}
  dump('dense-peak-positions.json',peaks)
  dump('dense-refinement-summary.json',summary);print(json.dumps(summary,indent=2))
 elif mode=='effects':
  controls={
   'top_width_y_halved':{**SPEC,'layers':[[90,70,30,1.65,0,1.45,0],SPEC['layers'][1],SPEC['layers'][2]]},
   'lower_width_y_halved':{**SPEC,'layers':[SPEC['layers'][0],SPEC['layers'][1],[130,95,40,1.45,0,1.6,0]]},
   'both_patterns_removed_background':{**SPEC,'layers':[[90,150,140,1.45,0,1.45,0],SPEC['layers'][1],[130,150,140,1.6,0,1.6,0]]},
  }
  wls=list(range(450,851,20));res={}
  for name,spec in controls.items():
   rows=[{'wavelength_nm':wl,**compare(run('meent',5,wl),run('meent',5,wl,spec,name))} for wl in wls];dump(name+'-effects.json',rows)
   worst=max(rows,key=lambda r:r['maximum']['absolute']);res[name]={'input':spec,'maximum_change':{'wavelength_nm':worst['wavelength_nm'],**worst['maximum']}}
  dump('pattern-effects-summary.json',res);print(json.dumps(res,indent=2))
