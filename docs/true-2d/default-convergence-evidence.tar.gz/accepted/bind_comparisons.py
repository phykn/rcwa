"""Replay persisted signed comparisons and bind every endpoint to its generation.
This performs no solver calls: only cache hits and exact-array comparisons.
"""
from validate import *
records=[]

def verify_file(name,ea,ha,eb,hb,tag_a='default',tag_b='default',wls=None):
 path=OUT/name;raw=json.loads(path.read_text());rows=raw if isinstance(raw,list) else [raw]
 if wls is None:wls=[row['wavelength_nm'] for row in rows]
 assert len(rows)==len(wls)
 bindings=[]
 for row,wl in zip(rows,wls):
  def read(engine,h,tag):
   spec=SPEC if tag=='default' else json.loads((OUT/'pattern-effects-summary.json').read_text())[tag]['input']
   sample=run(engine,h,wl,spec,tag)
   rel=f'samples/{tag}/{engine}/H{h}/{wl:.9f}.json'
   return sample,{'path':rel,'sha256':hashlib.sha256((OUT/rel).read_bytes()).hexdigest(),**{key:sample[key] for key in ['generation_id','input_sha256','cache_fingerprint']}}
  a,source_a=read(ea,ha,tag_a);b,source_b=read(eb,hb,tag_b)
  regenerated=compare(a,b)
  assert {key:value for key,value in row.items() if key!='wavelength_nm'}==regenerated, 'Signed residual mismatch: '+name
  bindings.append({'wavelength_nm':wl,'subtraction':'b minus a; common integer order labels; added order tails from b','a':source_a,'b':source_b,'signed_residual_values_verified':len(regenerated['signed_residuals']),'signed_added_tail_values_verified':len(regenerated['added_order_tails'])})
 records.append({'comparison_path':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'rows':bindings})
base_pairs=[('meent_H5_H7','meent',5,'meent',7),('meent_H7_H9','meent',7,'meent',9),('S4_H5_H7','S4',5,'S4',7),('S4_H7_H9','S4',7,'S4',9),('meent_H5_H9','meent',5,'meent',9),('meent_H5_S4_H9','meent',5,'S4',9),('meent_H9_S4_H9','meent',9,'S4',9)]
for label,ea,ha,eb,hb in base_pairs:verify_file(label+'.json',ea,ha,eb,hb)
for label,ea,ha,eb,hb in base_pairs[:-1]:verify_file('dense-'+label+'.json',ea,ha,eb,hb)
controls=json.loads((OUT/'control-convergence-summary.json').read_text())
for name,entry in controls.items():
 wl=entry['wavelength_nm']
 for label,ea,ha,eb,hb in [base_pairs[i] for i in [0,1,2,3,5]]:verify_file('control-'+name+'-'+label+'.json',ea,ha,eb,hb,name,name,[wl])
 verify_file('control-'+name+'-independent-effect.json','S4',9,'S4',9,'default',name,[wl])
 verify_file(name+'-effects.json','meent',5,'meent',5,'default',name)
report={'status':'Every persisted signed residual and retained signed added-order tail was exactly replayed from source-bound caches, and every endpoint is byte-hash/generation/input-bound. No solve or historical accepted cache reuse.','comparisons':records,'comparison_files':len(records),'comparison_rows':sum(len(r['rows']) for r in records),'signed_values_verified':sum(b['signed_residual_values_verified']+b['signed_added_tail_values_verified'] for r in records for b in r['rows'])}
dump('comparison-source-bindings.json',report);print(json.dumps({key:value for key,value in report.items() if key not in ['comparisons']},indent=2))
