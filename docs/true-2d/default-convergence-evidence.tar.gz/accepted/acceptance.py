from validate import *
full=json.loads((OUT/'full-summary.json').read_text());dense=json.loads((OUT/'dense-refinement-summary.json').read_text());controls=json.loads((OUT/'control-convergence-summary.json').read_text());audit=json.loads((OUT/'integrity-audit.json').read_text());exact=json.loads((OUT/'candidate-exact-replay.json').read_text())
gates=[]
for scope,summary in [('default_21_wavelengths',full),('dense_40_samples',dense)]:
 for pair,data in summary['comparisons'].items():
  if pair in ['meent_H5_H7','meent_H7_H9','S4_H5_H7','S4_H7_H9']:
   gates.append({'scope':scope,'comparison':pair,'maximum':data['worst'],'tolerance':5e-4,'pass':data['worst']['absolute']<=5e-4})
  elif pair=='meent_H5_S4_H9':
   gates.append({'scope':scope,'comparison':pair,'maximum':data['worst'],'tolerance':2e-3,'pass':data['worst']['absolute']<=2e-3})
  tail=data['worst_tail'];gates.append({'scope':scope,'comparison':pair+'_summed_added_order_tail','maximum':{k:v for k,v in tail.items() if k!='orders'},'tolerance':5e-4,'pass':tail['absolute']<=5e-4})
for name,control in controls.items():
 for pair,data in control['refinements'].items():
  tol=2e-3 if pair=='meent_H5_S4_H9' else 5e-4
  gates.append({'scope':'control_'+name,'comparison':pair,'maximum':data['maximum'],'tolerance':tol,'pass':data['maximum']['absolute']<=tol})
 gates.append({'scope':'control_'+name,'comparison':'effect_exceeds_sum_observed_reference_discrepancies','ratio':control['effect_to_sum_of_observed_discrepancies'],'pass':control['effect_to_sum_of_observed_discrepancies']>1})
start=json.loads((OUT/'provenance.json').read_text());end=json.loads((OUT/'provenance-final.json').read_text())
gates.append({'scope':'provenance','comparison':'engine_source_and_binary_unchanged','pass':start['hashes']==end['hashes'] and start['S4_commit']==end['S4_commit'] and not end['S4_tracked_diff']})
gates.append({'scope':'exact_candidate_input','comparison':'ordinary_H5_full21_replay_vs_fingerprinted_samples','maximum':exact['maximum_vs_single_wavelength_actual_samples'],'tolerance':1e-12,'pass':exact['maximum_vs_single_wavelength_actual_samples']['absolute']<=1e-12 and not exact['offline_reference_override'] and exact['validate_result_2d_passed'] and exact['PublicForwardResult2D_passed'] and exact['shared_validate_result_for_project_passed'] and exact['exact_shared_hash_matched']})
peaks=json.loads((OUT/'dense-peak-positions.json').read_text());shifts=[]
for center,engines in peaks.items():
 for engine,data in engines.items():
  for pol in ['s','p']:
   for what in ['maximum','minimum']:
    shifts.append({'center_nm':float(center),'engine':engine,'polarization':pol,'extremum':what,'H5_nm':data['5'][pol][what][0],'H7_nm':data['7'][pol][what][0],'H9_nm':data['9'][pol][what][0],'H5_H9_shift_nm':data['9'][pol][what][0]-data['5'][pol][what][0]})
result={'accepted':all(g['pass'] for g in gates),'scope':'Exact synthetic lossless subwavelength centered-rectangle multilayer candidate, Hx=Hy=5,21default wavelengths450:20:850nm;40additional dense samples around discovered extrema/steepest intervals','core_checkpoint':CORE_CHECKPOINT,'exact_candidate_input_hash':exact['input_hash'],'generation_ids':{e:get_generation(e)[0] for e in ['meent','S4']},'default_samples':21,'dense_samples':len(dense['wavelengths_nm']),'unique_default_and_dense_samples':len(set(full['wavelengths_nm'])|set(dense['wavelengths_nm'])),'gates':gates,'cache_audit_verified_samples':audit['accepted_cache_entries_verified'],'all_orders_lossless_tails_note':'Every newly added order is evanescent in both lossless ports, so physical added-order flux tails are zero; retained S4 floating-point signed tail residuals reach 1.673e-22 in the default/dense gates. This is not absorbing-port tail evidence.','reciprocal_light_line_lower_bound':450/max(SPEC['px'],SPEC['py'])-SPEC['n0']*math.sin(math.radians(SPEC['theta'])),'largest_finite_index':2.1,'dense_peak_shifts':shifts,'largest_sampled_H5_H9_peak_position_shift_nm':max(abs(s['H5_H9_shift_nm']) for s in shifts),'sampling_limitation':'Peak positions are sampled at0.5nm in local windows and at1nm in the exploratory discovery scan. This is not a proof that every sub-grid resonance is absent or that arbitrary edits converge.'}
dump('acceptance.json',result)
print(json.dumps({'accepted':result['accepted'],'failed':[g for g in gates if not g['pass']],'generations':result['generation_ids'],'input_hash':exact['input_hash'],'samples':result['unique_default_and_dense_samples'],'peak_shift_nm':result['largest_sampled_H5_H9_peak_position_shift_nm']},indent=2))
if not result['accepted']:raise SystemExit(2)
