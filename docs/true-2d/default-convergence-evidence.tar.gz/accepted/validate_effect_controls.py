from validate import *
controls=json.loads((OUT/'pattern-effects-summary.json').read_text());summary={}
for name,entry in controls.items():
 spec=entry['input'];wl=entry['maximum_change']['wavelength_nm']
 for engine in ['meent','S4']:
  for h in [5,7,9]:run(engine,h,wl,spec,name)
 pairs={}
 for label,ea,ha,eb,hb in [('meent_H5_H7','meent',5,'meent',7),('meent_H7_H9','meent',7,'meent',9),('S4_H5_H7','S4',5,'S4',7),('S4_H7_H9','S4',7,'S4',9),('meent_H5_S4_H9','meent',5,'S4',9)]:
  pair=compare(run(ea,ha,wl,spec,name),run(eb,hb,wl,spec,name));dump('control-'+name+'-'+label+'.json',pair);pairs[label]={k:pair[k] for k in ['maximum','added_order_tail_maximum']}
 independent_effect=compare(run('S4',9,wl),run('S4',9,wl,spec,name));dump('control-'+name+'-independent-effect.json',independent_effect)
 base_error=short_compare(run('meent',5,wl),run('S4',9,wl))['maximum']['absolute'];control_error=pairs['meent_H5_S4_H9']['maximum']['absolute']
 summary[name]={'wavelength_nm':wl,'production_H5_effect':entry['maximum_change'],'independent_S4_H9_effect':independent_effect['maximum'],'refinements':pairs,'base_H5_vs_reference_error':base_error,'control_H5_vs_reference_error':control_error,'effect_to_sum_of_observed_discrepancies':independent_effect['maximum']['absolute']/(base_error+control_error)}
dump('control-convergence-summary.json',summary);print(json.dumps(summary,indent=2))
